def load_from_sql():
    return " loaded the data and dumped the sql to downloads"