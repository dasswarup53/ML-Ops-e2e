import pandas as pd
import numpy as np
import mlflow
import matplotlib.pyplot as plt
import gc
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import AdaBoostClassifier
# from catboost import CatBoostClassifier
import xgboost as xgb
import mlflow.xgboost
import mlflow.sklearn
import json
from urllib.parse import urlparse



RFC_METRIC = 'gini'  #metric used for RandomForrestClassifier
NUM_ESTIMATORS = 100 #number of estimators used for RandomForrestClassifier
NO_JOBS = 4 #number of parallel jobs used for RandomForrestClassifier


#TRAIN/VALIDATION/TEST SPLIT
#VALIDATION
VALID_SIZE = 0.20 # simple validation using train_test_split
TEST_SIZE = 0.20 # test size using_train_test_split

#CROSS-VALIDATION
NUMBER_KFOLDS = 5 #number of KFolds for cross-validation



RANDOM_STATE = 2018

MAX_ROUNDS = 1000 #lgb iterations
EARLY_STOP = 50 #lgb early stop
OPT_ROUNDS = 1000  #To be adjusted based on best validation rounds
VERBOSE_EVAL = 50 #Print out metric result

data_df=pd.read_csv("/Users/apple/Downloads/creditcard.csv")


target = 'Class'
predictors = ['Time', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10',\
       'V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19',\
       'V20', 'V21', 'V22', 'V23', 'V24', 'V25', 'V26', 'V27', 'V28',\
       'Amount']

print(data_df.shape)
mlflow.set_tracking_uri("http://0.0.0.0:5000")
mlflow.set_experiment("Fraud-models")

with mlflow.start_run():
    mlflow.log_param("test_size", TEST_SIZE)
    mlflow.log_param("ML-model", "XGBOOST")
    train_df, test_df = train_test_split(data_df, test_size=TEST_SIZE, random_state=RANDOM_STATE, shuffle=True)
    # train_df, valid_df = train_test_split(train_df, test_size=VALID_SIZE, random_state=RANDOM_STATE, shuffle=True )
    kf = KFold(n_splits=NUMBER_KFOLDS, random_state=RANDOM_STATE, shuffle=True)
    oof_preds = np.zeros(train_df.shape[0])
    test_preds = np.zeros(test_df.shape[0])
    feature_importance_df = pd.DataFrame()
    n_fold = 0
    model_list = []
    for train_idx, valid_idx in kf.split(train_df):
        dtrain = xgb.DMatrix(train_df[predictors].iloc[train_idx], train_df[target].iloc[train_idx].values)
        dvalid = xgb.DMatrix(train_df[predictors].iloc[valid_idx], train_df[target].iloc[valid_idx].values)
        dtest = xgb.DMatrix(test_df[predictors], test_df[target].values)

        # What to monitor (in this case, **train** and **valid**)
        watchlist = [(dtrain, 'train'), (dvalid, 'valid')]

        # Set xgboost parameters
        params = {}
        params['objective'] = 'binary:logistic'
        params['eta'] = 0.039
        params['silent'] = True
        params['max_depth'] = 2
        params['subsample'] = 0.8
        params['colsample_bytree'] = 0.9
        params['eval_metric'] = 'auc'
        params['random_state'] = RANDOM_STATE
        mlflow.xgboost.autolog()
        # mlflow.log_param("ML-model", "XGBOOST")
        # mlflow.log_param("Params", json.dumps(params))
        model = xgb.train(params,
                          dtrain,
                          MAX_ROUNDS,
                          watchlist,
                          early_stopping_rounds=EARLY_STOP,
                          maximize=True,
                          verbose_eval=VERBOSE_EVAL)
        model_list.append(model)
        preds = model.predict(dtest)
        mlflow.log_metric("roc_auc_score",roc_auc_score(test_df[target].values, preds))
        # Model registry does not work with file store
        n_fold = n_fold + 1
        break
    tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme
    if tracking_url_type_store != "file":
        mlflow.xgboost.log_model(model_list[-1], "model", registered_model_name="XGBOOST")
    else:
        mlflow.xgboost.log_model(model[-1], "model")