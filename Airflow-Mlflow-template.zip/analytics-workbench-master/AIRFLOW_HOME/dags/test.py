from mlflow.tracking import MlflowClient
from pprint import pprint
import mlflow

def get_production_artifact():
    mlflow.set_tracking_uri("http://0.0.0.0:5000")
    client = MlflowClient()
    for rm in client.list_registered_models():
        # pprint(dict(rm), indent=4)
        #get the latest version list
        latest_versions=dict(rm)['latest_versions']
        for version_data in latest_versions:
            reg_model=dict(version_data)
            if reg_model['current_stage']=='Production':
                print("reg model artifcta source : ", reg_model['source'])
                print("reg model description : ", reg_model['description'])
                print("reg model version : ",reg_model['version'])
                print(reg_model['name'])
                return str(reg_model['source'])
        

