'''

curl -X POST -H "Content-Type:application/json; format=pandas-split" --data '{"columns":["Time","V1","V2","V3","V4","V5","V6","V7","V8","V9","V10","V11","V12","V13","V14","V15","V16","V17","V18","V19","V20","V21","V22","V23","V24","V25","V26","V27","V28","Amount"],"data":[[1.0,12.8,0.029,0.48,0.98,6.2,29.1,3.33,1.2,0.39,75.1,0.66,11.2,1.3,0.2,12.8,0.029,0.45,0.98,6.2,29,3.33,1.2,0.39,75.3,0.3,2.2,1.3,2.2,1.01]]}' http://127.0.0.1:1234/invocations

'''


from mlflow.tracking import MlflowClient
from pprint import pprint
import mlflow
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from datetime import datetime ,timedelta
def get_production_artifact(**kwargs):
    mlflow.set_tracking_uri("http://0.0.0.0:5000")
    client = MlflowClient()
    for rm in client.list_registered_models():
        # pprint(dict(rm), indent=4)
        # get the latest version list
        latest_versions = dict(rm)['latest_versions']
        for version_data in latest_versions:
            reg_model = dict(version_data)
            if reg_model['current_stage'] == 'Production':
                print("reg model artifcta source : ", reg_model['source'])
                print("reg model description : ", reg_model['description'])
                print("reg model version : ", reg_model['version'])
                print(reg_model['name'])
                task_instance = kwargs['ti']
                task_instance.xcom_push(key='file', value=str(reg_model['source']))
                return str(reg_model['source'])


with DAG('Model_Publishing',
                default_args= {
                'owner': 'swarup',
                'start_date':datetime.now() - timedelta(hours= 6),
                'concurrency': 2,
                'retries': 0
            },
          description='Model Deployment') as dag:

    get_production_artifact_operator=PythonOperator(task_id= 'search_ml_production_artifact',
                                   python_callable= get_production_artifact,provide_context=True)

    bash_deployment_operator=BashOperator(task_id='bash_deployment_operator'
                                    , bash_command = "mlflow models serve -m {{ti.xcom_pull(task_ids='search_ml_production_artifact')}} -p 1234 --no-conda")



get_production_artifact_operator>>bash_deployment_operator
