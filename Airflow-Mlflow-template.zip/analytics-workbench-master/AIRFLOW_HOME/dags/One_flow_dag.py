from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime, timedelta
from Load_Dump import load_data_from_sql
from Feature_Engineering import feature_engineering
from Models.Rf_flow import run_Rf_flow
from Models.Xgboost_flow import run_Xgboost_flow

from datetime import datetime, timedelta

def print_hello():
    return 'Hello world!'

def load_data_sql():
    return 'loaded data from sql and dumped the csv'

def preprocess_feature_engineering():
    return 'data is pre-processed and features are created and dumped '

def model_training():
    return ' model training completed '

def model_eval_metric():
    return ' the model has  good precision and recall scores '

def model_deployment():
    return 'the old model is removed and the new model is in place and serving '

def preserve_learned_coefficients():
    return 'coeficients are preserved into sql db'

def real_time_performance_monitoring_reporting():
    return  'used is viewing the dashboard'


with DAG('Data_Pipeline',
                default_args= {
                'owner': 'swarup',
                'start_date':datetime.now() - timedelta(hours= 6),
                'concurrency': 2,
                'retries': 0
            },
          description='Continuous Deployment & Delivery For ML',
            schedule_interval= '*/30 * * * *') as dag:
#
# dummy_operator= DummyOperator(task_id= 'dummy_task', retries= 3, dag= dag)
#
# hello_operator= PythonOperator(task_id= 'hello_task',
#                                python_callable= print_hello,
#                                dag= dag)
#
#
    load_operator=PythonOperator(task_id= 'load_data_sql',
                                   python_callable= load_data_sql)

    preprocess_feature_engineering_operator=PythonOperator(task_id= 'preprocess_feature_engineering',
                                   python_callable= preprocess_feature_engineering)

    random_forest_training_operator=PythonOperator(task_id= 'random_forest_training',
                                   python_callable=run_Rf_flow)

    xgboost_training_operator=PythonOperator(task_id= 'xgboost_training',
                                   python_callable=run_Xgboost_flow)
    # model_training_operator=PythonOperator(task_id= 'model_training',
    #                                python_callable= model_training)
    #
    # model_eval_metric_operator=PythonOperator(task_id= 'model_eval_metric',
    #                                python_callable= model_eval_metric)
    #
    # model_deployment_operator=PythonOperator(task_id= 'model_deployment',
    #                                python_callable= model_deployment)
    #
    # preserve_learned_coefficients_operator=PythonOperator(task_id= 'preserve_learned_coefficients_sql',
    #                                python_callable= preserve_learned_coefficients)
    #
    # real_time_performance_monitoring_reporting_operator=PythonOperator(task_id= 'real_time_performance_monitoring_reporting',
    #                                python_callable= real_time_performance_monitoring_reporting)

load_operator.set_downstream(preprocess_feature_engineering_operator)
preprocess_feature_engineering_operator.set_downstream(random_forest_training_operator)
preprocess_feature_engineering_operator.set_downstream(xgboost_training_operator)
# model_training_operator.set_downstream(model_eval_metric_operator)
# model_eval_metric_operator.set_downstream(model_deployment_operator)
# model_eval_metric_operator.set_downstream(preserve_learned_coefficients_operator)
# model_deployment_operator.set_downstream(real_time_performance_monitoring_reporting_operator)




