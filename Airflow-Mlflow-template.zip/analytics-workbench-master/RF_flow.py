'''
Run ml server using
mlflow server --backend-store-uri sqlite:///mlflow.db  --default-artifact-root /Users/apple/PycharmProjects/data-load/mlflow_example/ml_data/ --host 0.0.0.0

'''


import pandas as pd
import numpy as np
import mlflow
import matplotlib.pyplot as plt
import gc
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import roc_curve
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score , accuracy_score ,precision_score ,recall_score ,f1_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import AdaBoostClassifier
# from catboost import CatBoostClassifier
import xgboost as xgb
import mlflow.xgboost
from mlflow.tracking.client import MlflowClient
import mlflow.sklearn
import json
from urllib.parse import urlparse
from matplotlib import pyplot


RFC_METRIC = 'gini'  #metric used for RandomForrestClassifier
NUM_ESTIMATORS = 100 #number of estimators used for RandomForrestClassifier
NO_JOBS = 4 #number of parallel jobs used for RandomForrestClassifier


#TRAIN/VALIDATION/TEST SPLIT
#VALIDATION
VALID_SIZE = 0.20 # simple validation using train_test_split
TEST_SIZE = 0.20 # test size using_train_test_split

#CROSS-VALIDATION
NUMBER_KFOLDS = 5 #number of KFolds for cross-validation



RANDOM_STATE = 2018

MAX_ROUNDS = 1000 #lgb iterations
EARLY_STOP = 50 #lgb early stop
OPT_ROUNDS = 1000  #To be adjusted based on best validation rounds
VERBOSE_EVAL = 50 #Print out metric result

data_df=pd.read_csv("/Users/apple/Downloads/creditcard.csv")


target = 'Class'
predictors = ['Time', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10',\
       'V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19',\
       'V20', 'V21', 'V22', 'V23', 'V24', 'V25', 'V26', 'V27', 'V28',\
       'Amount']

print(data_df.shape)
mlflow.set_tracking_uri("http://0.0.0.0:5000")
mlflow.set_experiment("Fraud-models")
with mlflow.start_run():
    print(mlflow.get_tracking_uri())
    print(mlflow.get_artifact_uri())
    # mlflow.log_param("test_size",TEST_SIZE)
    mlflow.log_param("ML-model", "RandomForest")
    mlflow.log_params({"criterion":"gini","max_depth":5,"max_features":"auto"})
    # mlflow.log_param("Params",json.dumps({"criterion":"gini","max_depth":5,"max_features":"auto"}))
    train_df, test_df = train_test_split(data_df, test_size=TEST_SIZE, random_state=RANDOM_STATE, shuffle=True )
    # train_df, valid_df = train_test_split(train_df, test_size=VALID_SIZE, random_state=RANDOM_STATE, shuffle=True )

    kf = KFold(n_splits = NUMBER_KFOLDS, random_state = RANDOM_STATE, shuffle = True)
    oof_preds = np.zeros(train_df.shape[0])
    test_preds = np.zeros(test_df.shape[0])
    feature_importance_df = pd.DataFrame()
    n_fold = 0
    model_list=[]
    for train_idx, valid_idx in kf.split(train_df):
        train_x, train_y = train_df[predictors].iloc[train_idx],train_df[target].iloc[train_idx]
        valid_x, valid_y = train_df[predictors].iloc[valid_idx],train_df[target].iloc[valid_idx]
        evals_results = {}
        model = RandomForestClassifier(n_estimators=50,
        criterion='gini',
        max_depth=5,
        min_samples_split=2,
        min_samples_leaf=1,
        min_weight_fraction_leaf=0.0,
        max_features='auto',
        max_leaf_nodes=None,
        min_impurity_decrease=0.0,
        min_impurity_split=None,
        bootstrap=True,
        oob_score=False,
        n_jobs=-1,
        random_state=0,
        verbose=0,
        warm_start=False,
        class_weight='balanced')
        model_list.append(model.fit(train_x, train_y))
        oof_preds[valid_idx] = model.predict_proba(valid_x)[:, 1]
        print('Fold %2d AUC : %.6f' % (n_fold + 1, roc_auc_score(valid_y, oof_preds[valid_idx])))
        mlflow.log_metric("roc_auc_score",roc_auc_score(valid_y, oof_preds[valid_idx]))
        mlflow.log_metric("accuracy",accuracy_score(valid_y,[1 if x > 0.5 else 0 for x in oof_preds[valid_idx]]))
        mlflow.log_metric("f1-score",f1_score(valid_y,[1 if x > 0.5 else 0 for x in oof_preds[valid_idx]]))
        mlflow.log_metric("precision",precision_score(valid_y,[1 if x > 0.5 else 0 for x in oof_preds[valid_idx]]))
        mlflow.log_metric("recall",recall_score(valid_y,[1 if x > 0.5 else 0 for x in oof_preds[valid_idx]]))

        tracking_url_type_store = urlparse(mlflow.get_tracking_uri()).scheme
        # Model registry does not work with file store

        n_fold = n_fold + 1
    #     labels = [0,1]
    #     print(valid_y[0:20])
    #     print(oof_preds[valid_idx][0:20])
    #     cm = confusion_matrix(valid_y, [1 if x > 0.5 else 0 for x in oof_preds[valid_idx]], labels)
    #     print(cm)
    #     fig = plt.figure()
    #     ax = fig.add_subplot(111)
    #     cax = ax.matshow(cm)
    #     plt.title('Confusion matrix of the classifier')
    #     fig.colorbar(cax)
    #     ax.set_xticklabels([''] + labels)
    #     ax.set_yticklabels([''] + labels)
    #     plt.xlabel('Predicted')
    #     plt.ylabel('True')
    #     plt.savefig("./plots/"+str(n_fold)+".png")
    # mlflow.log_artifact("./plots/1.png")
    client = MlflowClient()

    if tracking_url_type_store != "file":

        # Register the model
        # There are other ways to use the Model Registry, which depends on the use case,
        # please refer to the doc for more information:
        # https://mlflow.org/docs/latest/model-registry.html#api-workflow
        mlflow.sklearn.log_model(model_list[-1], "model", registered_model_name="RandomForestModel")
    else:
        mlflow.sklearn.log_model(model_list[-1], "model")
    client.transition_model_version_stage(
        name="RandomForestModel",
        version=1,
        stage="Production"
    )
    predictions = model_list[-1].predict_proba(test_df[predictors])

    lr_fpr, lr_tpr, _ = roc_curve(test_df[target].values, predictions[:, 1])
    # # plot the roc curve for the model
    # pyplot.plot(ns_fpr, ns_tpr, linestyle='--', label='No Skill')
    pyplot.plot(lr_fpr, lr_tpr, marker='.', label='RandomForest')
    # # axis labels
    pyplot.xlabel('False Positive Rate')
    pyplot.ylabel('True Positive Rate')
    # # show the legend
    pyplot.legend()
    pyplot.savefig("./plots/roc_curve.png")
    mlflow.log_artifact("./plots/roc_curve.png")
    # # show the plot
    # pyplot.show()



